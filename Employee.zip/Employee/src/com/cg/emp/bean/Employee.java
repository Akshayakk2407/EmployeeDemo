package com.cg.emp.bean;

public class Employee 
{
	
	public Employee(int empId, String empName, double salary, String scheme) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.Salary = salary;
		this.scheme = scheme;
	}
	public Employee(String empName, double salary, String scheme) {
		super();
		this.empName = empName;
		Salary = salary;
		this.scheme = scheme;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", Salary=" + Salary + ", scheme=" + scheme + "]";
	}
	private int empId;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	private String empName;
	private double Salary;
	private String scheme;
	
}
