package com.cg.emp.service;

import java.util.List;

import com.cg.emp.bean.Employee;
import com.cg.emp.exceptions.EmpException;

public interface IEmpService {

	public void validateSalary(double salary)throws EmpException;

	 List<Employee> getAllDetails()throws EmpException;

	public void validateName(String empName)throws EmpException;

	public int addEmployee(Employee emp)throws EmpException;

	

	

}
