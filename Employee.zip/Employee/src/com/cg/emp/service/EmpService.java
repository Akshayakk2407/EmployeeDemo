package com.cg.emp.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.emp.bean.Employee;
import com.cg.emp.dao.employeeDao;
import com.cg.emp.exceptions.EmpException;


public class EmpService implements IEmpService {
public void validateName(String Name) throws EmpException {
		
		String nameRegEx = "[a-zA-Z]{5,10}";
		if (!Pattern.matches(nameRegEx, Name)) {
			throw new EmpException("first letter should be capital and length must be in between 5 to 10");
		}
	}
	@Override
	public void validateSalary(double salary) throws EmpException {
		if (salary > 25000) {
			System.out.println("scheme A");
		}
			else if(salary<25000) {
				System.out.println("Scheme B");
			}
		if(salary==0)
			throw new EmpException("Salary should not be 0");
		
}


	public List <Employee> getAllDetails() throws EmpException {
		
		return employeeDao.getAllDetails();
	}

	
	

	@Override
	public int addEmployee(Employee emp) throws EmpException {
		return employeeDao.addEmployee(emp);
	}

	
}
