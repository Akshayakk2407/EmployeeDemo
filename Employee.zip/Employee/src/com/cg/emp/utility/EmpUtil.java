package com.cg.emp.utility;

import java.util.ArrayList;
import java.util.List;

import com.cg.emp.bean.Employee;



public class EmpUtil {
	private static List<Employee> list = new ArrayList<>();

	static {

		list.add(new Employee(111, "Akshaya", 45000d,"SCHEME A"));
		list.add (new  Employee (222, "Asha", 55000d,"Scheme B"));
		list.add(new  Employee (333, "Fenisha", 25000d,"Scheme A"));
		list.add (new  Employee(444, "Mamatha", 27000d,"Scheme B"));
		list.add (new  Employee(555, "Riyana", 75000d, "Scheme A"));
	}

	public static List<Employee> getList() {
		return list;
	}

	public static void setList(List<Employee> list) {
		EmpUtil.list = list;
	}
}
