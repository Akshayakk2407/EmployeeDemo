package com.cg.emp.exceptions;

	public class EmpException extends Exception {

		public EmpException(String message) {
			super(message);
		}
	}


