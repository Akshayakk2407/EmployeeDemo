package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.bean.Employee;
import com.cg.emp.exceptions.EmpException;

public interface IEmpDao {
	public List<Employee> getAllDetails() throws EmpException ;
	
	public int addEmployee(Employee emp) throws EmpException;
}
