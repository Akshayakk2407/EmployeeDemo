package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.bean.Employee;
import com.cg.emp.exceptions.EmpException;
import com.cg.emp.utility.EmpUtil;


public class employeeDao {
	
	public static List<Employee> getAllDetails() throws EmpException {
		return EmpUtil.getList();
	}

	
		public static int addEmployee(Employee emp) throws EmpException {

			int id = (int) (Math.random() * 1000);
			emp.setEmpId(id);

			List<Employee> empd = EmpUtil.getList();
			empd.add(emp);

			// PMSUtil.getList().add(product);

			return id;
		}


	}

