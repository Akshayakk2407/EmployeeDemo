package com.cg.emp.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.emp.bean.Employee;
import com.cg.emp.exceptions.EmpException;
import com.cg.emp.service.EmpService;
import com.cg.emp.service.IEmpService;



public class Main 
{
	public static void main(String args[])
	{
		//Employee emp= new Employee();
		Scanner sc=null;
		IEmpService service=new EmpService();
		String Continue = "";
		
		do {

			System.out.println("******Empolyee Management System******");
			System.out.println("1.Add Details");
			
			System.out.println("2.Display Details");
			System.out.println("3.exit");
			
			int choice = 0;
			boolean choiceFlag = false;

			do {
				sc = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = sc.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:

						String EmpName = "";
						boolean EmpNameFlag = false;

						do {
							sc= new Scanner(System.in);
							System.out.println("Enter your name");
							try {
								EmpName = sc.nextLine();
								service.validateName(EmpName);
								EmpNameFlag = true;
								break;
							} catch (EmpException e) {
								EmpNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!EmpNameFlag);

						double Salary = 0;
						boolean SalaryFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Salary:");
							try {
								Salary = sc.nextDouble();
								service.validateSalary(Salary);
								SalaryFlag = true;
								break;
							} catch (InputMismatchException e) {
								SalaryFlag = false;
								System.err.println("Salary should be digits");
							} 
							catch (EmpException e) 
							
							{
								SalaryFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!SalaryFlag);
						sc = new Scanner(System.in);
						System.out.println("enter scheme");
						String scheme = sc.nextLine();


						//sc = new Scanner(System.in);
						//System.out.println("enter quantity");
						//int quantity = scanner.nextInt();

						// Product product = new Product(productId, productName, productCost, quantity);
					Employee emp = new Employee(EmpName, Salary,scheme);
						try {
							int generatedId = service.addEmployee(emp);
							System.out.println("Employee Details are added with the id: " + generatedId);
					} catch (EmpException e) {
						System.out.println(e.getMessage());
						}

						break;
					case 2:

						List<Employee> empd = null;
						try {
							empd = service.getAllDetails();
							for (Employee ac : empd) {
								System.out.println(ac);
							}
						} catch (EmpException e) {
							System.err.println(e.getMessage());
						}
						break;

					case 3:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("input should be 1, 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			sc = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			Continue = sc.nextLine();

		} while (Continue.equalsIgnoreCase("yes"));
		sc.close();
				
			
						
	}

}
